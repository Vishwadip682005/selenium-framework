package base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import utils.DriverFactory;

public class BaseTest {
	protected WebDriver driver;
	boolean keepBrowserOpen = true;
    @BeforeMethod
    public void setup() {
        driver = DriverFactory.initDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/");
    }

    @AfterMethod
    public void tearDown() {
        if (!keepBrowserOpen) {
        	driver.quit();
        }
    }
}
