package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PIMPage {
	WebDriver driver;

    
    By pimMenu = By.xpath("//span[text()='PIM']");
    By addEmployeeBtn = By.xpath("//button[text()=' Add ']");
    By firstName = By.name("firstName");
    By lastName = By.name("lastName");
    By saveBtn = By.xpath("//button[@type='submit']");
    By successHeader = By.xpath("//h6[text()='Personal Details']");
    
    By employeeNameSearch = By.xpath("//input[@placeholder='Type for hints...']");
    By searchBtn = By.xpath("//button[@type='submit']");
    
    By editField = By.name("firstName");
    
    By deleteBtn = By.xpath("//button[contains(@class,'delete')]");
    public PIMPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isEmployeeAdded() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(successHeader));
        return driver.findElement(successHeader).isDisplayed();
    }
    	public void addEmployee(String fname, String lname) {
        driver.findElement(pimMenu).click();
        driver.findElement(addEmployeeBtn).click();
        driver.findElement(firstName).sendKeys(fname);
        driver.findElement(lastName).sendKeys(lname);
        driver.findElement(saveBtn).click();
    }
    	public void searchEmployee(String name) {
            driver.findElement(pimMenu).click();
            driver.findElement(employeeNameSearch).sendKeys(name);
            driver.findElement(searchBtn).click();
        }
    	public boolean verifyEmployeeDetails() {
            return driver.findElement(successHeader).isDisplayed();
        }
    	public void editEmployee(String newName) {
            driver.findElement(editField).clear();
            driver.findElement(editField).sendKeys(newName);
        }
    	public void deleteEmployee() {
            driver.findElement(deleteBtn).click();
        }
}
